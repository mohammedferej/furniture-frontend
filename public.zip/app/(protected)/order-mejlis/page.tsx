'use client';

import MejlisFormParent from '@/components/MejlisFormParent';

export default function OrderMejlisPage() {
  return <MejlisFormParent />;
}
